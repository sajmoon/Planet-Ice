Bomberman Java
Version : 1.0
Author  : Michel MAC WING
Web     : http://sourceforge.net/projects/javabomberman

To compile and obtain javadoc ( ./docs/javadoc ):
under unix  : install
under win32 : install.bat

To clean ( delete *~ *.class *.java.bak files ) :
under unix  : clean
under win32 : clean.bat

To fix rights on files and directories :
under unix  : rights.sh

To create more levels for this games :
see package "niveau" and sub-package "niveau.level"

To participate/develop this project, contact me :
e-mail : mwmichel@free.fr

For license, read GNU-GPL.txt